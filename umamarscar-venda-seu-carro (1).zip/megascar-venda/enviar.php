<?php
/* =========================================================
   Megas Car – recebe o formulário "Venda seu Carro"
   e envia por e-mail (com as fotos em anexo).
   Funciona na hospedagem compartilhada da Hostinger.
   ========================================================= */

// >>> CONFIGURE AQUI <<<
$DESTINO  = 'contato@umamarscar.com.br';   // e-mail que recebe as avaliações
$REMETENTE = 'site@umamarscar.com.br';     // crie esta conta em Hostinger > E-mails (precisa ser do seu domínio)
$MAX_FOTOS = 8;
$MAX_TAM   = 5 * 1024 * 1024;            // 5 MB por foto

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'erro' => 'Método inválido']);
    exit;
}

function campo($n) { return trim(strip_tags($_POST[$n] ?? '')); }

$obrig = ['marca', 'modelo', 'ano', 'km', 'nome', 'telefone', 'email'];
foreach ($obrig as $o) {
    if (campo($o) === '') {
        echo json_encode(['ok' => false, 'erro' => "Campo obrigatório: $o"]);
        exit;
    }
}
if (!filter_var(campo('email'), FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['ok' => false, 'erro' => 'E-mail inválido']);
    exit;
}

$rotulos = [
    'marca' => 'Marca', 'modelo' => 'Modelo', 'versao' => 'Versão', 'ano' => 'Ano',
    'km' => 'Quilometragem', 'cambio' => 'Câmbio', 'combustivel' => 'Combustível',
    'cor' => 'Cor', 'placa' => 'Placa', 'valor' => 'Valor pretendido', 'obs' => 'Observações',
    'nome' => 'Nome', 'telefone' => 'Telefone/WhatsApp', 'email' => 'E-mail',
    'cidade' => 'Cidade/Bairro', 'contato' => 'Preferência de contato',
];

$html = '<h2 style="font-family:Arial">Nova avaliação – Venda seu Carro</h2><table cellpadding="6" style="font-family:Arial;border-collapse:collapse">';
foreach ($rotulos as $k => $r) {
    $v = htmlspecialchars(campo($k), ENT_QUOTES, 'UTF-8');
    if ($v !== '') $html .= "<tr><td style='background:#f3f3f3'><b>$r</b></td><td>" . nl2br($v) . "</td></tr>";
}
$html .= '</table><p style="font-family:Arial;color:#888">Enviado em ' . date('d/m/Y H:i') . '</p>';

$boundary = md5(uniqid((string)mt_rand(), true));
$assunto  = '=?UTF-8?B?' . base64_encode('Venda seu Carro: ' . campo('marca') . ' ' . campo('modelo') . ' – ' . campo('nome')) . '?=';

$headers  = "From: Megas Car Site <$REMETENTE>\r\n";
$headers .= "Reply-To: " . campo('email') . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";

$corpo  = "--$boundary\r\n";
$corpo .= "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
$corpo .= chunk_split(base64_encode($html)) . "\r\n";

// Anexa as fotos
if (!empty($_FILES['fotos']['name'][0])) {
    $total = min(count($_FILES['fotos']['name']), $MAX_FOTOS);
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    for ($i = 0; $i < $total; $i++) {
        if ($_FILES['fotos']['error'][$i] !== UPLOAD_ERR_OK) continue;
        if ($_FILES['fotos']['size'][$i] > $MAX_TAM) continue;
        $tmp  = $_FILES['fotos']['tmp_name'][$i];
        $mime = $finfo->file($tmp);
        if (strpos($mime, 'image/') !== 0) continue;
        $nome = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($_FILES['fotos']['name'][$i]));
        $corpo .= "--$boundary\r\n";
        $corpo .= "Content-Type: $mime; name=\"$nome\"\r\n";
        $corpo .= "Content-Transfer-Encoding: base64\r\n";
        $corpo .= "Content-Disposition: attachment; filename=\"$nome\"\r\n\r\n";
        $corpo .= chunk_split(base64_encode(file_get_contents($tmp))) . "\r\n";
    }
}
$corpo .= "--$boundary--";

$enviado = mail($DESTINO, $assunto, $corpo, $headers, "-f$REMETENTE");

echo json_encode($enviado ? ['ok' => true] : ['ok' => false, 'erro' => 'Falha ao enviar e-mail']);
